<?php
require_once 'modules/connexion.php';
// Initialiser la connexion à la base de données
Connexion::initConnexion();

// Vérifiez si le paramètre "module" est défini
if (isset($_GET['module'])) {
    $module = $_GET['module'];

    // Vérifiez le module demandé et incluez le fichier du module approprié
    switch ($module) {
        case 'joueurs':
            require_once 'modules/mod_joueurs/mod_joueurs.php';
            new ModJoueurs();
            break;
        case 'equipes':
            require_once 'modules/mod_equipes/mod_equipes.php';
            new ModEquipes();
            break;
        // Ajoutez d'autres cas pour d'autres modules si nécessaire
        default:
            // Gestion d'erreur : module non reconnu
            echo "Module non reconnu.";
            break;
    }
} else {
    // Gestion d'erreur : le paramètre "module" n'est pas défini
    echo "Paramètre 'module' manquant.";
}
?>
