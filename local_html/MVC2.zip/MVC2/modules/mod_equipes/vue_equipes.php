<?php
class VueEquipes {
     public function affiche_liste($elements) {
    echo '<ul>';
    foreach ($elements as $element) {
        echo '<li><a href="index.php?module=equipes&action=details&id=' . $element['id'] . '">' . $element['nom'] . '</a></li>';
    }
    echo '</ul>';
}

 
    public function affiche_details($details) {
        echo '<h2>Détails de l\'équipe</h2>';
        echo '<p>ID : ' . $details['id'] . '</p>';
        echo '<p>Nom : ' . $details['nom'] . '</p>';
        echo '<p>Année de création : ' . $details['annee_creation'] . '</p>';
        echo '<p>Description : ' . $details['description'] . '</p>';
        //echo '<p>Pays : ' . $details['pays'] . '</p>';
        echo '<p>Logo : ' . $details['logo'] . '</p>';
    }


public function menu($action) {
        echo '<ul>';
        echo '<li><a href="index.php?module=equipes&action=bienvenue">Bienvenue</a></li>';
        echo '<li><a href="index.php?module=equipes&action=liste">Liste</a></li>';
        echo '</ul>';
    }
}

?>


 
