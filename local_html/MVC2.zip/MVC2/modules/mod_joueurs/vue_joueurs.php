<?php
class VueJoueurs {
     public function affiche_liste($elements) {
    echo '<ul>';
    foreach ($elements as $element) {
        echo '<li><a href="index.php?module=joueurs&action=details&id=' . $element['id'] . '">' . $element['nom'] . '</a></li>';
    }
    echo '</ul>';
}

 public function affiche_details($details) {
        echo '<h2>Détai ls du joueur</h2>';
        echo '<p>ID : ' . $details['id'] . '</p>';
        echo '<p>Nom : ' . $details['nom'] . '</p>';
        echo '<p>Description : ' . $details['bio'] . '</p>';
    }


public function menu($action) {
        echo '<ul>';
        echo '<li><a href="index.php?module=joueurs&action=bienvenue">Bienvenue</a></li>';
        echo '<li><a href="index.php?module=joueurs&action=liste">Liste</a></li>';
        echo '</ul>';
    }

public function form_ajout() {
    echo '<h2>Ajouter un joueur</h2>';
    echo '<form method="post" action="index.php?module=joueurs&action=ajout">';
    echo 'Nom : <input type="text" name="nom"><br>';
    echo 'Bio : <textarea name="bio"></textarea><br>';
    echo '<input type="submit" value="Ajouter">';
    echo '</form>';
}

   
}

?>