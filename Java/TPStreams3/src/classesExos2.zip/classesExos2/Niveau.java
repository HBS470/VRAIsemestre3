package enonce;
public enum Niveau {
    S1, S2, S3, M1, M2
}
